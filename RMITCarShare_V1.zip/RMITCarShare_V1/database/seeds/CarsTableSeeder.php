<?php

use Illuminate\Database\Seeder;
use App\Car;

class CarsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Car::truncate();

        Car::create([
            'make' => 'Hyundai',
            'model' => 'i20',
            'type' => 'Hatchback',
            'latitude' => -37.807563,
            'longitude' => 144.962911
        ]);

        Car::create([
            'make' => 'Hyundai',
            'model' => 'i20',
            'type' => 'Hatchback',
            'latitude' => -37.796781,
            'longitude' => 144.965483
        ]);

        Car::create([
            'make' => 'Hyundai',
            'model' => 'i20',
            'type' => 'Hatchback',
            'latitude' => -37.800444,
            'longitude' => 144.968816
        ]);

        Car::create([
            'make' => 'Hyundai',
            'model' => 'i20',
            'type' => 'Hatchback',
            'latitude' => -37.805519,
            'longitude' => 144.961574
        ]);

        Car::create([
            'make' => 'Hyundai',
            'model' => 'Santa Fe',
            'type' => 'SUV',
            'latitude' => -37.815474,
            'longitude' => 144.960907
        ]);

        Car::create([
            'make' => 'Toyota',
            'model' => 'Hiace',
            'type' => 'Van',
            'latitude' => -37.814492,
            'longitude' => 145.009845
        ]);
    }
}
